> Replace me with your issue!


##### Disclaimer:

 - [ ] I have read the guidelines for contributing linked to above.
 - [ ] This issue is related to the limetext project as a whole and would not belong better in one of the individual package repositories found [here](https://github.com/limetext).
 - [ ] I have checked for duplicate issues.
 - [ ] This is not a [support request](https://github.com/limetext/support).
